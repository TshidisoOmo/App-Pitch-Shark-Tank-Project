const KEY="safecircle-v1";
const defaultState={profile:{name:"",codePhrase:""},contacts:[],alerts:[
 {title:"Community safety reminder",details:"Stay aware of your surroundings and use trusted contacts when travelling alone.",time:"Just now"}
],journey:null};
let state=load();
let sosTimer=null, sosRemaining=10, deferredInstall=null;

function load(){try{return {...defaultState,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return structuredClone(defaultState)}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function toast(msg){const t=document.querySelector("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2800)}
function showScreen(id){
 document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===id));
 document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.screen===id));
 render();
}
document.querySelectorAll("[data-screen]").forEach(b=>b.addEventListener("click",()=>showScreen(b.dataset.screen)));

function render(){
 const home=document.querySelector("#homeAlerts"); home.innerHTML=state.alerts.slice(0,3).map(alertHTML).join("");
 const contacts=document.querySelector("#contacts");
 contacts.innerHTML=state.contacts.length?state.contacts.map((c,i)=>`<div class="item"><b>${esc(c.name)}</b> <span class="pill">${esc(c.role)}</span><div class="muted">${esc(c.phone)}</div><div class="item-actions"><a href="tel:${encodeURIComponent(c.phone)}">Call</a><button type="button" data-remove-contact="${i}">Remove</button></div></div>`).join(""):"<div class='muted'>No trusted contacts added yet.</div>";
 contacts.querySelectorAll("[data-remove-contact]").forEach(b=>b.onclick=()=>{state.contacts.splice(+b.dataset.removeContact,1);save();render();toast("Contact removed")});
 const list=document.querySelector("#alertList"); list.innerHTML=state.alerts.map(alertHTML).join("");
 const pf=document.querySelector("#profileName"); if(document.activeElement!==pf)pf.value=state.profile.name||"";
 const cp=document.querySelector("#codePhrase"); if(document.activeElement!==cp)cp.value=state.profile.codePhrase||"";
 renderJourney();
}
function alertHTML(a){return `<div class="item"><span class="pill">Community</span><h3>${esc(a.title)}</h3><div>${esc(a.details)}</div><small class="muted">${esc(a.time||"")}</small></div>`}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

document.querySelector("#contactForm").addEventListener("submit",e=>{
 e.preventDefault();const name=document.querySelector("#contactName").value.trim(),phone=document.querySelector("#contactPhone").value.trim(),role=document.querySelector("#contactRole").value;
 if(!name||!phone)return; state.contacts.push({name,phone,role});save();e.target.reset();render();toast("Trusted contact added");
});
document.querySelector("#alertForm").addEventListener("submit",e=>{
 e.preventDefault();const title=document.querySelector("#alertTitle").value.trim(),details=document.querySelector("#alertDetails").value.trim();
 if(!title||!details)return;state.alerts.unshift({title,details,time:new Date().toLocaleString()});save();e.target.reset();render();toast("Alert saved on this device");
});
document.querySelector("#profileForm").addEventListener("submit",e=>{
 e.preventDefault();state.profile.name=document.querySelector("#profileName").value.trim();state.profile.codePhrase=document.querySelector("#codePhrase").value.trim();save();toast("Profile saved");
});
document.querySelector("#clearData").onclick=()=>{if(confirm("Clear SafeCircle data stored on this device?")){localStorage.removeItem(KEY);state=load();render();toast("Local data cleared")}};

function renderJourney(){
 const box=document.querySelector("#journeyState");
 if(!state.journey){box.innerHTML="";return}
 const j=state.journey, d=new Date(j.arrival), now=Date.now(), mins=Math.max(0,Math.round((d-now)/60000));
 box.innerHTML=`<div class="card"><span class="pill">Journey active</span><h2>${esc(j.destination)}</h2><p>From ${esc(j.start)}</p><p><b>Expected arrival:</b> ${d.toLocaleString()}</p><p><b>${mins}</b> minutes remaining.</p><button class="danger-outline" id="endJourney">I arrived safely</button></div>`;
 document.querySelector("#endJourney").onclick=()=>{state.journey=null;save();render();toast("Journey checked in. Stay safe!")};
}
document.querySelector("#journeyForm").addEventListener("submit",e=>{
 e.preventDefault();const start=document.querySelector("#startPoint").value.trim(),destination=document.querySelector("#destination").value.trim(),arrival=document.querySelector("#arrival").value;
 const d=new Date(arrival);if(!destination||Number.isNaN(d.getTime())||d<=new Date()){toast("Choose a future arrival time.");return}
 state.journey={start,destination,arrival:d.toISOString()};save();render();toast("Safe Journey started");
});
setInterval(()=>{if(state.journey){renderJourney()}},30000);

async function shareLocation(){
 if(!navigator.geolocation){toast("Location is not supported by this browser.");return}
 toast("Requesting your location…");
 navigator.geolocation.getCurrentPosition(async pos=>{
   const {latitude,longitude}=pos.coords;
   const text=`SafeCircle emergency location: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
   if(navigator.share){try{await navigator.share({title:"SafeCircle location",text,url:`https://maps.google.com/?q=${latitude},${longitude}`});toast("Location share opened");return}catch{}}
   window.open(`https://maps.google.com/?q=${latitude},${longitude}`,"_blank","noopener");
   toast("Map opened with your current location");
 },()=>toast("Location permission was denied or unavailable."),{enableHighAccuracy:true,timeout:10000});
}
document.querySelector('[data-action="location"]').onclick=shareLocation;

function openSos(){
 const modal=document.querySelector("#sosModal");modal.classList.remove("hidden");sosRemaining=10;document.querySelector("#count").textContent=sosRemaining;
 clearInterval(sosTimer);sosTimer=setInterval(()=>{sosRemaining--;document.querySelector("#count").textContent=sosRemaining;if(sosRemaining<=0){clearInterval(sosTimer);activateSos()}},1000);
}
function closeSos(){clearInterval(sosTimer);document.querySelector("#sosModal").classList.add("hidden")}
function activateSos(){
 clearInterval(sosTimer);document.querySelector("#sosModal").classList.add("hidden");
 document.querySelector("#safeStatus").className="status emergency";document.querySelector("#safeStatus").textContent="⚠ EMERGENCY ACTIVE";
 toast("Emergency activated. Use the call options below.");
 showScreen("numbers");
 shareLocation();
}
document.querySelector("#sosBtn").onclick=openSos;document.querySelector("#cancelSos").onclick=closeSos;document.querySelector("#activateSos").onclick=activateSos;

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;document.querySelector("#installBtn").classList.remove("hidden")});
document.querySelector("#installBtn").onclick=async()=>{if(!deferredInstall){toast("Use your browser menu and choose Install/Add to Home Screen.");return}deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null};

if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
render();